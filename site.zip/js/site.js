// Contact form: until a form backend is connected, "Send" opens the visitor's email app
// with everything they filled in, addressed to the studio.
(function () {
  var form = document.getElementById('form');
  if (!form) return;
  var btn = form.querySelector('button');
  var fields = form.querySelectorAll('label');
  function val(label) {
    var el = label.querySelector('input,select,textarea');
    return el ? el.value.trim() : '';
  }
  function name(label) {
    return (label.firstChild && label.firstChild.textContent || '').trim();
  }
  btn.addEventListener('click', function () {
    var data = {}, missing = [];
    fields.forEach(function (l) {
      var n = name(l), v = val(l);
      data[n] = v;
      if ((n === 'Name' || n === 'Email') && !v) missing.push(l.querySelector('input'));
    });
    if (missing.length) { missing[0].focus(); missing[0].reportValidity && missing[0].setCustomValidity('Please fill this in'); missing[0].reportValidity(); missing[0].setCustomValidity(''); return; }
    var body = Object.keys(data).filter(function (k) { return data[k]; })
      .map(function (k) { return k + ': ' + data[k]; }).join('\n\n');
    var subject = 'New project: ' + (data['Business or brand'] || data['Name']);
    location.href = 'mailto:hadarhanuka@gmail.com?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);
  });
})();
